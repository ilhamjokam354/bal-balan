document.addEventListener("DOMContentLoaded", function(){
    getIdDetailTeam()
   
})